# Electrical Guru Android App

This project packages the Stitch-exported Electrical Guru HTML screens into an Android WebView application.

## Build APK
1. Install Android Studio (recent stable version).
2. Open this folder (`ElectricalGuruAndroid`) in Android Studio.
3. Let Gradle sync and install the Android SDK Platform 35 if Android Studio asks.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Run the `app` configuration to test.
6. For an APK: **Build → Generate App Bundles or APKs → Generate APKs**.

The debug APK is normally produced under:
`app/build/outputs/apk/debug/app-debug.apk`

## Notes
- The Stitch pages are bundled under `app/src/main/assets/electrical_guru/`.
- The app starts at the Electrical Guru Home screen.
- A floating ☰ button opens a module navigator for the exported screens.
- The exported screens use Tailwind CDN and Google Fonts, so internet access is allowed for the same visual styling.
