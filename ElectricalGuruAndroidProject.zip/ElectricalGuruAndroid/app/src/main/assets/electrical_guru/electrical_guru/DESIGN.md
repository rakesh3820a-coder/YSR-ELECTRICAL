---
name: Electrical Guru
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#434655'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#565d79'
  on-secondary: '#ffffff'
  secondary-container: '#d8deff'
  on-secondary-container: '#5a627e'
  tertiary: '#784b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#996100'
  on-tertiary-container: '#ffeedd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#bec5e5'
  on-secondary-fixed: '#131a33'
  on-secondary-fixed-variant: '#3e4660'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
  nav-dark: '#0B132B'
  surface-lab: '#F8FAFC'
  surface-card: '#FFFFFF'
  border-grid: '#E2E8F0'
  circuit-green: '#10B981'
  circuit-green-light: '#ECFDF5'
  warning-amber: '#F59E0B'
  warning-amber-light: '#FFFBEB'
  danger-red: '#EF4444'
  cobalt-deep: '#1D4ED8'
  accent-cyan: '#0284C7'
typography:
  display:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
  technical-code:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-base: 1rem
  space-lg: 1.25rem
  space-xl: 1.5rem
  space-2xl: 2rem
---

## Brand & Style

This design system is engineered for practical technical education in electrical and electronic engineering, serving Diploma candidates, B.Tech undergraduates, trade apprentices, and job seekers. The aesthetic blends the authoritative precision of an engineering laboratory workbench with the streamlined ergonomics of a modern mobile operating system.

Key brand values include:
- **Laboratory Precision:** Information hierarchy prioritizes schematics, circuit values, pinouts, and test protocols with clear, unmistakable visual cues.
- **Empowering Practicality:** Step-by-step experiment modules, breadboard visualizers, and interactive simulators bridge theoretical textbook formulas and hands-on workshop execution.
- **Industrial Rigor & Safety:** Visual cues derive from global electrical standards—amber warnings for safety precautions, live signal emeralds for test verifications, and high-voltage cobalt accents for primary navigation and interactive controls.

The visual style is **Modern Technical Utility**: dark navy command headers and structural navigation anchors, paired with crisp lab-white card containers, technical gray hairline borders, high-density badge metadata, and tactile physical component representations.

## Colors

The color palette reflects real-world electrical equipment, digital multimeters, test benches, and schematic design CAD tools:

- **Primary (`#2563EB` Electric Cobalt):** Powers all high-priority user actions, primary call-to-action buttons ("Start Practical", "Run Simulation", "Play"), selected tab pill states, and active schematic nodes.
- **Secondary (`#0B132B` Deep Instrument Navy):** Provides high-contrast anchor areas including top app bars, header banners, bottom navigation docks, and dark simulator canvas containers.
- **Tertiary (`#F59E0B` Industrial Caution Amber):** Designates safety warnings, high-voltage advisories, breadboard step cautions, and streak/achievement highlights.
- **Neutral (`#64748B` Technical Slate):** Supplies secondary text labels, component specification keys, breadboard pin coordinate indices, and structural separator strokes.

### Functional Circuit Colors
- **Circuit Test Green (`#10B981` / `#ECFDF5`):** Denotes verified continuity, correct quiz answers, passing voltages, and completed experiment checkpoints.
- **Danger Red (`#EF4444`):** Indicates polarity reversal, short-circuit alerts, simulator overload states, and incorrect quiz answers.
- **Lab Surface White (`#F8FAFC` & `#FFFFFF`):** Form the baseline backdrop and elevated card sheets, ensuring high contrast for complex electronic diagrams and micro-step instructions.

## Typography

The typography pairings balance technical engineering aesthetics with screen legibility:

- **Display & Section Titles (`Space Grotesk`):** Chosen for its geometric, engineered cadence reminiscent of architectural blueprints and industrial instrumentation. Used in top headers, topic titles, and milestone markers.
- **Body & Explanatory Prose (`Inter`):** Delivers clean readability for multi-step wiring instructions, component functional breakdowns, and quiz stems.
- **Technical & Metric Readouts (`JetBrains Mono`):** Applied to electrical specifications (e.g., `220Ω`, `+9V`, `0.05 mA`, `1N4007`), schematic terminal markings, timer counts, and step index badges.

## Layout & Spacing

The layout is optimized for single-handed mobile navigation and touch interaction during workbench activities:

- **Grid Architecture:** Standard 4-column fluid mobile grid with 16px (`1rem`) outer screen margins and 16px gutters between grid tiles.
- **Vertical Spacing Rhythm:** Component stacks enforce strict 8px/12px spacing intervals. Dense metadata rows (ratings, pinouts, part counts) utilize compact 4px–6px gaps to preserve visual grouping.
- **Safe Interaction Zones:** Fixed bottom toolbars, action sheets, and floating test buttons retain 34px bottom padding on edge-to-edge mobile devices to clear system navigation bars.
- **Modular Reflow:** On tablet viewports, horizontal split-screens pair schematic diagrams on the left with wiring steps and verification checklists on the right.

## Elevation & Depth

Visual hierarchy combines clean tonal surfaces with subtle atmospheric drop shadows:

- **Level 0 (Canvas Base):** Background workspace rendered in `#F8FAFC` to distinguish interactive cards from the canvas.
- **Level 1 (Card & Module Layer):** Pure white (`#FFFFFF`) cards bordered with a crisp `1px solid #E2E8F0` hairline. Elevated using an ambient shadow: `0 1px 3px 0 rgba(11, 19, 43, 0.05), 0 1px 2px -1px rgba(11, 19, 43, 0.05)`.
- **Level 2 (Active/Selected Card & Quick Action):** Interactive cards, hover states, or active quiz options elevate with `0 4px 6px -1px rgba(11, 19, 43, 0.08), 0 2px 4px -2px rgba(11, 19, 43, 0.05)` and a primary cobalt perimeter border.
- **Level 3 (Fixed Overlays & Bottom Navigators):** Deep navy header bars and bottom dock navigation use `0 10px 15px -3px rgba(11, 19, 43, 0.15)`.
- **Level 4 (Schematic & Breadboard Canvas):** Recessed canvas featuring an inset border `inset 0 1px 2px rgba(0, 0, 0, 0.06)` with subtle dot-matrix alignment guides mimicking PCB breadboard matrices.

## Shapes

The design adopts **Level 2 (Rounded)** shape geometry, pairing soft corners with industrial precision:

- Standard cards, module items, and input fields use `rounded-md` (8px / `0.5rem`).
- Primary call-to-action buttons, filter segment tabs, and component preview chips use `rounded-lg` (12px / `0.75rem`) to maintain comfortable thumb targets.
- Numerical step badges, pinout indicators, status pills, and bottom navigation icon containers use circular or pill geometry (`rounded-full`) to immediately signal categorical and sequential status.

## Components

### Buttons & CTAs
- **Primary Action ("Start Practical", "Run Simulation", "Play"):** Solid `#2563EB` fill, white bold text, 48px height, 12px border radius. On active press, tone shifts to `#1D4ED8`.
- **Secondary / Ghost Action:** 1px `#CBD5E1` border over `#FFFFFF`, `#0B132B` text with an optional left-aligned technical icon.
- **Danger Action ("Reset Circuit"):** Semi-transparent red border with `#EF4444` label, or subtle tinted pill on dark toolbars.

### Navigation Header & Bottom Dock
- **Header:** Rich navy `#0B132B` background with crisp white typography, amber logo sparks, integrated search trigger, and back chevron navigation.
- **Bottom Navigation Dock:** Deep navy shell (`#0B132B`) holding 5 key destinations (Home, Learn, Practical, Simulator, Profile). Active destination is emphasized with an electric cobalt accent container and glowing yellow/white icon indicator.

### Segmented Filter Chips
- Horizontal scrolling pill lists for categorizing modules (e.g., `All`, `Basic`, `Machines`, `Power System`).
- **Active Pill:** Solid `#2563EB` background with white label.
- **Inactive Pill:** Neutral surface `#F1F5F9` background with `#475569` label and `1px solid #E2E8F0`.

### Step Indicators & Safety Advisory Banners
- **Wiring Step Badge:** Circle of 24px diameter in `#2563EB` containing a centered mono numeral (`1`, `2`, `3`), followed by explicit terminal connection directions.
- **Safety Warning Banner:** Background `#FFFBEB` with `1px solid #FCD34D`, featuring an amber warning triangle icon and structured bullet points highlighting critical safety rules (polarity, supply voltage limits).

### Component Inspection Cards
- White rectangular card with real-world photographic or isometric component rendering (resistor, capacitor, diode, relay, motor).
- Structured tabular technical sheet:
  - **Function:** Concise engineering utility description.
  - **Symbol:** CAD schematic symbol vector.
  - **Ratings:** Voltage, current, resistance, wattage in `JetBrains Mono`.
  - **Real-Life Use:** Field application summary.

### Quiz & Verification Modules
- **Option Container:** Card row with a circle prefix (`A`, `B`, `C`, `D`) and schematic image or text answer.
- **Correct State:** Green accent outline (`#10B981`), light emerald fill (`#ECFDF5`), and checkmark badge.
- **Incorrect State:** Red accent outline (`#EF4444`) and subtle red tint.

### Circuit Simulator Canvas
- High-contrast interactive breadboard canvas with grid alignment markers, tactile wire-routing paths, and direct terminal-snap interaction points.