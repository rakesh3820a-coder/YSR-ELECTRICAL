package com.electricalguru.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private WebView webView;
    private final Map<String,String> modules = new LinkedHashMap<>();

    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(11,19,43));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(11,19,43));

        modules.put("Home", "electrical_guru_home/code.html");
        modules.put("Learn", "electrical_guru_learn/code.html");
        modules.put("Practical Lab", "electrical_guru_practical_lab/code.html");
        modules.put("Circuit Simulator", "electrical_guru_circuit_simulator/code.html");
        modules.put("Component Library", "electrical_guru_component_library/code.html");
        modules.put("Quiz", "electrical_guru_quiz/code.html");
        modules.put("Fault Diagnostic", "electrical_guru_fault_diagnostic/code.html");
        modules.put("Multimeter Probing", "electrical_guru_multimeter_probing/code.html");
        modules.put("Motor Test Run", "electrical_guru_motor_test_run_resolution/code.html");
        modules.put("Star-Delta Troubleshooting", "electrical_guru_star_delta_starter_troubleshooting/code.html");
        modules.put("Star-Delta Schematics", "electrical_guru_star_delta_schematics/code.html");
        modules.put("230V Control Ladder", "electrical_guru_control_circuit_ladder_230v/code.html");
        modules.put("OLR Trip State", "electrical_guru_control_circuit_ladder_olr_trip_state/code.html");
        modules.put("Reset / Standby", "electrical_guru_control_circuit_ladder_reset_standby/code.html");
        modules.put("Star Mode Active", "electrical_guru_control_circuit_ladder_star_mode_active/code.html");
        modules.put("Delta Mode Active", "electrical_guru_control_circuit_ladder_delta_mode_active/code.html");
        modules.put("Motor Terminal Box", "motor_terminal_junction_box_delta_mode/code.html");
        modules.put("Continuity Testing", "terminal_stud_resistance_continuity_testing/code.html");
        modules.put("Open-Circuit Fault", "terminal_stud_resistance_open_circuit_fault_o.l/code.html");
        modules.put("Megger / Earth Fault", "motor_insulation_resistance_megger_coil_to_earth_fault/code.html");
        modules.put("Phase Flashover", "phase_to_phase_flashover_isolation_u1_v1_v1_w1/code.html");
        modules.put("Inter-Phase Short", "inter_phase_short_circuit_flashover_failure_0.00_m/code.html");
        modules.put("Complete 230V Ladder", "complete_230v_star_delta_control_ladder_diagram/code.html");
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(248,249,255));
        webView.setVerticalScrollBarEnabled(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                String u = req.getUrl().toString();
                if (u.startsWith("electricalguru://")) {
                    String path = u.substring("electricalguru://".length());
                    loadModule(path);
                    return true;
                }
                return false;
            }
            @Override public void onPageFinished(WebView view, String url) {
                injectAppMenu();
            }
        });
        setContentView(webView);
        loadModule("electrical_guru_home/code.html");
    }

    @Override public void onResume() { super.onResume(); if (webView == null) setupWebView(); }

    private void loadModule(String path) {
        if (webView != null) {
            webView.loadUrl("file:///android_asset/electrical_guru/" + path);
        }
    }

    private void injectAppMenu() {
        StringBuilder items = new StringBuilder();
        for (Map.Entry<String,String> e : modules.entrySet()) {
            items.append("<button data-path=\"")
                 .append(e.getValue().replace("\"", "&quot;"))
                 .append("\">")
                 .append(escape(e.getKey()))
                 .append("</button>");
        }
        String html = "<div id='eg-title'>Electrical Guru</div>" + items;
        String safe = html.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
        String js = "javascript:(function(){if(document.getElementById('eg-menu'))return;" +
                "var b=document.createElement('button');b.id='eg-fab';b.innerHTML='☰';" +
                "b.style.cssText='position:fixed;right:16px;bottom:18px;z-index:2147483647;width:52px;height:52px;border:0;border-radius:50%;background:#0B132B;color:white;font-size:24px;box-shadow:0 6px 18px rgba(0,0,0,.28)';" +
                "var m=document.createElement('div');m.id='eg-menu';m.style.cssText='display:none;position:fixed;right:14px;bottom:78px;z-index:2147483646;width:min(310px,88vw);max-height:72vh;overflow:auto;background:white;border-radius:18px;padding:12px;box-shadow:0 12px 40px rgba(0,0,0,.28);font-family:Arial,sans-serif';" +
                "m.innerHTML='" + safe + "';" +
                "var t=m.querySelector('#eg-title');t.style.cssText='font-size:18px;font-weight:700;padding:8px;color:#0B132B';" +
                "m.querySelectorAll('button').forEach(function(x){x.style.cssText='display:block;width:100%;text-align:left;border:0;background:#F1F5F9;color:#0B132B;padding:12px 14px;margin:6px 0;border-radius:12px;font-size:14px';x.onclick=function(){location.href='electricalguru://'+x.dataset.path}});" +
                "b.onclick=function(){m.style.display=m.style.display==='none'?'block':'none'};document.body.appendChild(m);document.body.appendChild(b);})()";
        webView.evaluateJavascript(js, null);
    }

    private static String escape(String s) { return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;"); }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
